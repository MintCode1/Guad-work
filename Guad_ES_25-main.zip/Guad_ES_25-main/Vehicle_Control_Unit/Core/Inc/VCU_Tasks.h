/*
 * VCU_Tasks.h
 *
 *  Created on: Apr 15, 2024
 *      Author: qiaomein
 */

#ifndef INC_VCU_TASKS_H_
#define INC_VCU_TASKS_H_


#include <stdio.h>
#include <string.h>
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"

//extern uint32_t TxMailbox;
//extern CAN_TxHeaderTypeDef TxHeader;
//extern uint8_t TxData[8];
//extern CAN_HandleTypeDef hcan1;

typedef struct {
	uint32_t timestamp;
	uint16_t frontGaps[4];
	uint16_t rearGaps[4];
	uint16_t hallEffect[4];
	uint8_t temperatures[12];
	uint8_t pressures[3];
	uint8_t tof[4];
	uint8_t current[2];

} SensorReading; // struct of a given sensor reading

//Use this to store a state of global sensor readings. This lets main access sensor readings
extern SensorReading globalSensorReadings;

//Set this flag whenever you get data
extern int dataFlag;

// functions

//void CAN_Transmit_Task();
void Health_Check_Task(); //Remove void* Parameters field since thats an RTOS thing, parameter itself isn't used
void FSM_Handler_Task();
void Initialization_Task();
void Ready_Task();
void Levitation_Task();
void Check_Bounds();
void Off_Task();
//extern void MX_CAN1_Init(void);




#endif /* INC_VCU_TASKS_H_ */
