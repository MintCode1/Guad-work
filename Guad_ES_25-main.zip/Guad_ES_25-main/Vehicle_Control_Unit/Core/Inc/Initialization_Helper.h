#include "main.h"
#include <stdio.h>
#include <string.h>
#include "FreeRTOS.h"
#include "task.h"
#include "VCU_Tasks.h"
#include "main.h"
#include "stm32f4xx_hal.h"

//Initialization tasks
void Init_Config(void);
void SystemClock_Config(void);
static void MX_CAN1_Init(void);
static void MX_I2C1_Init(void); 
static void MX_TIM2_Init(void);
static void MX_GPIO_Init(void);
void Error_Handler(void);