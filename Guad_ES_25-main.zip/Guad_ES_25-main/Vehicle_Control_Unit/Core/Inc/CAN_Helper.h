/*
 * CAN_Helper.h
 *
 *  Created on: Apr 15, 2024
 *      Author: qiaomein
 */

#ifndef INC_CAN_HELPER_H_
#define INC_CAN_HELPER_H_

#include "main.h"
#include <stdio.h>
#include <string.h>
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "stm32f4xx_hal.h"

//The CAN_Helper module handles reading sensor values from all the hub units
/* Global receive header and data --------------------------------------------------*/
extern CAN_TxHeaderTypeDef* pRxHeader;
extern uint8_t* pRxData;
typedef struct {
	CAN_HandleTypeDef* phcan; // pointer to can handler peripheral
	CAN_TxHeaderTypeDef* pTxHeader;
	uint32_t* pTxMailBox;
	uint8_t* pTxData;
} CAN_Bundle; // this CAN_Bundle is used to pass into the CAN_Transmit_Task

/* CAN functions -------------------------------------------------------------------*/
//void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *phcan);
CAN_Bundle createCAN_Bundle(CAN_HandleTypeDef* phcan);
void CAN_Transmit_Task(void *Parameters); //Transmit via CAN

#endif /* INC_CAN_HELPER_H_ */
