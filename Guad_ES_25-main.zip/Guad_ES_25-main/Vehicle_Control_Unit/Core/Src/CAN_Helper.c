/*
 * CAN_Helper.c
 *
 *  Created on: Apr 15, 2024
 *      Author: qiaomein
 */

#include "CAN_Helper.h"

//CAN globals
CAN_TxHeaderTypeDef TxHeader;
uint8_t TxData[8];
uint32_t TxMailbox;

//void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *phcan) {
//
//	HAL_CAN_GetRxMessage(phcan, CAN_RX_FIFO0, pRxHeader, *pRxData); // updates RxData and RxHeader
//	if (pRxHeader->StdId == CAN_VCU_ID) { // if this message is for VCU
//		globalSensorReadings.timestamp = HAL_GetTick(); // store all sensor readings into the sensor data buffer
//
//	}
//}


CAN_Bundle createCAN_Bundle(CAN_HandleTypeDef* phcan){
	CAN_Bundle cb;
	cb.phcan = phcan;

	return cb;
}

//Call this to transmit a message to CAN
void CAN_Transmit_Task(void *Parameters) {
	for(int i=0; i<13; i++){
	  HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox);

	  TxData[3]++;
	}
//					TxHeader.DLC = 8; //data length
//						  TxHeader.IDE = CAN_ID_STD;
//						  TxHeader.RTR = CAN_RTR_DATA;
//						  TxHeader.StdId = 0x001; //ID
//						TxData[0] = 0x03; //ms delay
//							TxData[1] = 0x22; //loop rep
//							TxData[2] = 0xF1;
//							TxData[3] = 0x00;
//							TxData[4] = 0x00;
//							TxData[5] = 0x00;
//							TxData[6] = 0x00;
//							TxData[7] = 0x00;
//					HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox);
}

