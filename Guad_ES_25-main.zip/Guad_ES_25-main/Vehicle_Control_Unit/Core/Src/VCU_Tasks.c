/*
 * VCU_Tasks.c
 *
 *  Created on: Apr 15, 2024
 *      Author: qiaomein
 */

#include "VCU_Tasks.h"

uint8_t RxData[8];
int dataFlag = 0;

CAN_RxHeaderTypeDef RxHeader;
SensorReading globalSensorReadings;

int Check_Bounds(){ //Returntype changed to int since BaseType_t is an RTOS type
	; // look at all the sensor readings and determine if we are in normal operating ranges
	return 0;
}

void Idle_Task(){
	//SDC open
	//EB deployed
	/* IMPLEMENT THAT HERE */

	//Busy loop wait for message
	while(dataFlag == 0 /* IMPLEMENT ADDITIONAL CONDITIONAL DEPENDING ON WHAT MESSAGE WE WANT */){} //Leave idle upon receiving correct message
	dataFlag = 0;
}

void Active_Task(){
	//SDC closed
	//EB deployed
	/* IMPLEMENT THAT HERE */

	//Busy loop wait for message
	while(dataFlag == 0 /* IMPLEMENT ADDITIONAL CONDITIONAL DEPENDING ON WHAT MESSAGE WE WANT */){} //Leave idle upon receiving correct message
	dataFlag = 0;
}

void Emergency_Task(){
	//SDC open
	//EB deployed
	/* IMPLEMENT THAT HERE */

}

void Health_Check_Task() {
// 	read sensor values and asserts they are all normal readings
//	if (healthCheckPassed(globalSensorReadings) == pdFALSE){ // if health check failed
//		; // goto stopped state
//	}
	if(RxData[0]>0){
		FSM_Handler_Task();
	}
}

//This should be called when Main gets a message
void FSM_Handler_Task() { // should have regular priority
	switch (globalCurrentState) {
		case INITIALIZATION:
			
			break; // check for transitions here
		case HEALTH_CHECK:
			Health_Check_Task();
			break; // if hc passed go to ready state; if failed go back to initialization state
		case READY:
			
			break; // if signal from ccu, start pod run
		case LEVITATION:
			break; // if HC failed, goto stopped; if desired gaps reached and ccu sends signal, goto propulsion
		case PROPULSION:
			break; // timeout or hit the coasting marker along the track
		case COASTING:
			break; // timeout or hit the braking marker on the track then goto braking state
		case BRAKING:
			HAL_GPIO_WritePin(BRAKE_DIGITAL_GPIO_Port, BRAKE_DIGITAL_Pin, 0);
			break; // can only goto stopped state
		case STOPPED:
			break; // this is stopped state and can only be unstopped by GUI command
	}
}

void Initialization_Task(){
    // Comment indicates this sequence is for precharging the LEV DCDC converter
    // precharge for LEV DCDC sequence below

    // Two alternative delay methods are commented out:
    // 1. Simple HAL delay
    //HAL_Delay(5000);

    // SAFETY FIRST: Engage brakes before power sequence
    HAL_GPIO_WritePin(BRAKE_DIGITAL_GPIO_Port, BRAKE_DIGITAL_Pin, 0);

    // Initial system stabilization delay
    HAL_Delay(5000);

    // Commented out CAN message - would have sent status/command
    //HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox);

    // POWER SEQUENCE START
    // Disable levitation contactor
    HAL_GPIO_WritePin(CONTACTOR_LEV_GPIO_Port, CONTACTOR_LEV_Pin, 0);
    // Enable C3 (auxiliary contactor)
    HAL_GPIO_WritePin(CONTACTOR_3_GPIO_Port, CONTACTOR_3_Pin, 1);
    HAL_Delay(50);
    // Enable C1 (pre-charge contactor)
    HAL_GPIO_WritePin(CONTACTOR_1_GPIO_Port, CONTACTOR_1_Pin, 1);
    HAL_Delay(3000);
    // Enable C2 (main power contactor)
    HAL_GPIO_WritePin(CONTACTOR_2_GPIO_Port, CONTACTOR_2_Pin, 1);
    HAL_Delay(100);
    // Disable pre-charge contactor after main power established
    HAL_GPIO_WritePin(CONTACTOR_1_GPIO_Port, CONTACTOR_1_Pin, 0);

    // VFD INITIALIZATION
    // Set PWM to 0 for safety
    TIM2->CCR1 = 0;
    // Configure VFD direction control
    HAL_GPIO_WritePin(VFD_FORWARD_GPIO_Port, VFD_FORWARD_Pin, 1);
    HAL_GPIO_WritePin(VFD_REVERSE_GPIO_Port, VFD_REVERSE_Pin, 0);

    // SAFETY: Release brakes after all systems initialized
    HAL_GPIO_WritePin(BRAKE_DIGITAL_GPIO_Port, BRAKE_DIGITAL_Pin, 1);

    // Set system state to READY and notify FSM task
    globalCurrentState = READY;
}

void Ready_Task(){
	HAL_GPIO_WritePin(CONTACTOR_LEV_GPIO_Port, CONTACTOR_LEV_Pin, 1);
}

void Levitation_Task(){

}

//Automatically trigger on message receive
//Set globalSensorReadings
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan){
	dataFlag = 1; //Set flag
	HAL_GPIO_WritePin(CONTACTOR_1_GPIO_Port, CONTACTOR_1_Pin, 1);
	if(HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &RxHeader, RxData) == HAL_OK){
		if(RxData[0] == 0){ //condition will be the ccu command to go to lev state (nneds to check for ccu id and if global state ready)
		}
		else if(RxData[1] == 0){ //condition will be hub unit giving sensor data (check for hub unit ids)
		}
		else if(RxData[2] == 0){ //condition will be ccu command and gap height cond reached (check for ccu id and global state lev and global tick not 1min)

		}
		else if(RxData[3] == 0){//condition is if global state is lev or lim on or estop and tick diff has surpassed 1 min go to estop even if command is sent (check for ccu id)

		}
	}
}

//Off state in FSM
void Off_Task(){
	/* Add code here */
}

//void CAN_Transmit_Task() {
//	for(;;){
////		TxHeader.DLC = 8; //data length
////			  TxHeader.IDE = CAN_ID_STD;
////			  TxHeader.RTR = CAN_RTR_DATA;
////			  TxHeader.StdId = 0x7E3; //ID
////			TxData[0] = 0x03; //ms delay
////				TxData[1] = 0x22; //loop rep
////				TxData[2] = 0xF1;
////				TxData[3] = 0x00;
////				TxData[4] = 0x00;
////				TxData[5] = 0x00;
////				TxData[6] = 0x00;
////				TxData[7] = 0x00;
////		HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox);
//	}
//	TickType_t xLastWakeTime;
//	const TickType_t xFrequency = 2; // check sensor signals every tick (1000 Hz)
//
//	// CAN headers data
//
//	CAN_Bundle *pcan_bundle = (CAN_Bundle*) Parameters; // load in task parameter (should be &hcan) properly
//	CAN_HandleTypeDef *phcan = pcan_bundle->phcan; // ptr to the hcan peripheral
//	CAN_TxHeaderTypeDef *pTxHeader = pcan_bundle->pTxHeader;
//	uint32_t *pTxMailBox = pcan_bundle->pTxMailBox;
//
//	pTxHeader->DLC = 8; //data length
//	pTxHeader->IDE = CAN_ID_STD;
//	pTxHeader->RTR = CAN_RTR_DATA;
//	//pTxHeader->StdId = CAN_CCU_ID; // ID to send to
//	pTxHeader->TransmitGlobalTime = DISABLE;
//
//	// Initialise the xLastWakeTime variable with the current time.
//	xLastWakeTime = xTaskGetTickCount();
//
//	for (;;) {
//
//		// Wait for the next cycle.
//		HAL_DelayUntil(&xLastWakeTime, xFrequency);
//
//
//		// send data to CCU for telemetry
//
//		*(pcan_bundle->pTxData) = 0x01; // lil pointer arithemtic action
//		*(pcan_bundle->pTxData + 7) = 0x0F;
//
//		pTxHeader->StdId = CAN_CCU_ID;
//		HAL_CAN_AddTxMessage(phcan, pTxHeader, (uint8_t *) (pcan_bundle->pTxData), pTxMailBox); // send it away!
//
//		//pTxHeader->StdId = CAN_LCU_ID;
//		//HAL_CAN_AddTxMessage(phcan, pTxHeader, TxData, pTxMailBox); // send it away!
//
//	}

//}

//void MX_CAN1_Init(void)
//{
//
//  /* USER CODE BEGIN CAN1_Init 0 */
//
//  /* USER CODE END CAN1_Init 0 */
//
//  /* USER CODE BEGIN CAN1_Init 1 */
//
//  /* USER CODE END CAN1_Init 1 */
//  hcan1.Instance = CAN1;
//  hcan1.Init.Prescaler = 18;
//  hcan1.Init.Mode = CAN_MODE_NORMAL;
//  hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
//  hcan1.Init.TimeSeg1 = CAN_BS1_2TQ;
//  hcan1.Init.TimeSeg2 = CAN_BS2_2TQ;
//  hcan1.Init.TimeTriggeredMode = DISABLE;
//  hcan1.Init.AutoBusOff = DISABLE;
//  hcan1.Init.AutoWakeUp = DISABLE;
//  hcan1.Init.AutoRetransmission = DISABLE;
//  hcan1.Init.ReceiveFifoLocked = DISABLE;
//  hcan1.Init.TransmitFifoPriority = DISABLE;
//  if (HAL_CAN_Init(&hcan1) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  /* USER CODE BEGIN CAN1_Init 2 */
//
//	CAN_FilterTypeDef canfilterconfig;
//
//	canfilterconfig.FilterActivation = CAN_FILTER_ENABLE;
//
//
//	canfilterconfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;
//
//	canfilterconfig.FilterBank = 0; // which filter bank to use from the assigned ones
//	canfilterconfig.FilterIdHigh = 0x7EB << 5;
//	canfilterconfig.FilterIdLow = 0;
//	canfilterconfig.FilterMaskIdHigh = 0x7EB << 5;
//	canfilterconfig.FilterMaskIdLow = 0x0000;
//	canfilterconfig.FilterMode = CAN_FILTERMODE_IDMASK;
//	canfilterconfig.FilterScale = CAN_FILTERSCALE_32BIT;
//	canfilterconfig.SlaveStartFilterBank = 0;  // does not matter
//	HAL_CAN_ConfigFilter(&hcan1, &canfilterconfig);
//
//	canfilterconfig.FilterBank = 1; // which filter bank to use from the assigned ones
//	canfilterconfig.FilterIdHigh = CAN_FHU_ID << 5;
//	canfilterconfig.FilterIdLow = 0;
//	canfilterconfig.FilterMaskIdHigh = CAN_FHU_ID << 5;
//	canfilterconfig.FilterMaskIdLow = 0x0000;
//	canfilterconfig.FilterMode = CAN_FILTERMODE_IDMASK;
//	canfilterconfig.FilterScale = CAN_FILTERSCALE_32BIT;
//	canfilterconfig.SlaveStartFilterBank = 0;  // does not matter
//	HAL_CAN_ConfigFilter(&hcan1, &canfilterconfig);
//
//	canfilterconfig.FilterBank = 2; // which filter bank to use from the assigned ones
//	canfilterconfig.FilterIdHigh = CAN_RHU_ID << 5;
//	canfilterconfig.FilterIdLow = 0;
//	canfilterconfig.FilterMaskIdHigh = CAN_RHU_ID << 5;
//	canfilterconfig.FilterMaskIdLow = 0x0000;
//	canfilterconfig.FilterMode = CAN_FILTERMODE_IDMASK;
//	canfilterconfig.FilterScale = CAN_FILTERSCALE_32BIT;
//	canfilterconfig.SlaveStartFilterBank = 0;  // does not matter
//	HAL_CAN_ConfigFilter(&hcan1, &canfilterconfig);
//
//  /* USER CODE END CAN1_Init 2 */
//
//}
