/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "VCU_Tasks.h"
#include "Initialization_Helper.h" 
#include "CAN_Helper.h" 

/* Private includes ----------------------------------------------------------*/
CAN_HandleTypeDef hcan1;
I2C_HandleTypeDef hi2c1;
TIM_HandleTypeDef htim2;

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_CAN1_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM2_Init(void);

/* Main ----------------------------------------------------------------------*/
int main(void)
{
  // Vars
  typedef enum {
    PS_OFF = 0,
    PS_ON = 1,
    PS_FAIL = 2
  } PowerState;
  typedef enum {
    I_FAIL = 0,
    I_OP = 1,
    I_EQ = 2,
    I_RANGE = 3
  } InductiveState;
  typedef enum {
    HE_FAIL = 0,
    HE_OP = 1,
    HE_LEV = 2,
    HE_PROP = 3
  } HallState;
  typedef enum {
    T_FAIL = 0,
    T_OP = 1,
    T_LEV = 2,
    T_PROP = 3
  } TempState;
  typedef enum {
    IMU_FAIL = 0,
    IMU_OP = 1,
    IMU_SPEED = 2,
    IMU_TS = 3,
    IMU_DIST = 4,
    IMU_BRAKE_DIST = 5,
    IMU_STOP = 6
  } IMUState;
  
  // global states
  PowerState PS;
  InductiveState I;
  HallState HE;
  TempState T;
  IMUState IMU;
  int CC, WC, Start, HVon;
  int timer1, timer2, timer3, counter;
  int someLimit = 1000; //change - temp assignment

  typedef enum {
    STATE_OFF,
    STATE_INITIALIZE_ELECTRONICS,
    STATE_HEALTH_CHECK,
    STATE_COUNT_CHECK,
    STATE_READY_TO_LAUNCH,
    STATE_LEV_ON,
    STATE_CALIBRATE_LEV,
    STATE_PROPULSION_ON,
    STATE_ACCELERATE,
    STATE_COAST,
    STATE_NORMAL_BRAKE,
    STATE_EMERGENCY_BRAKE
  } State;

  State current_state = STATE_INITIALIZE_ELECTRONICS;
  bool running = true;

  while(running) {
    switch(current_state) {
      /*------------------------------*/
      /* State: Initialize Electronics */
      /*------------------------------*/
      case STATE_INITIALIZE_ELECTRONICS:
        Init_Config();
        Initialization_Task();
        
        if (PS == PS_OFF)
          current_state = STATE_OFF;
        else
          current_state = STATE_HEALTH_CHECK;
        break;

      /*---------------------*/
      /* State: Health Check */
      /*---------------------*/
      case STATE_HEALTH_CHECK:
        Health_Check_Task();
        
        if (PS == PS_OFF || PS == PS_FAIL)
          current_state = STATE_OFF;
        else if (HE && IMU && I && T && CC && WC)
          current_state = STATE_READY_TO_LAUNCH;
        else if (HE && IMU && I && T && CC && WC == 0)
          current_state = STATE_COUNT_CHECK;
        break;

      /*--------------------*/
      /* State: Count Check */
      /*--------------------*/
      case STATE_COUNT_CHECK:
        counter++;
        
        if (PS == PS_OFF || PS == PS_FAIL || counter > someLimit)
          current_state = STATE_OFF;
        else if (PS == PS_ON)
          current_state = STATE_INITIALIZE_ELECTRONICS;
        break;

      /*------------------------*/
      /* State: Ready to launch */
      /*------------------------*/
      case STATE_READY_TO_LAUNCH:
        /* timer 1 runs */
        if (!HE || !IMU || !I || !T || !CC || !WC)
          current_state = STATE_HEALTH_CHECK;
        else if (Start == 1)
          current_state = STATE_LEV_ON;
        else if (timer1 > someLimit || PS == PS_OFF)
          current_state = STATE_OFF;
        break;

      /*---------------*/
      /* State: Lev On */
      /*---------------*/
      case STATE_LEV_ON:
        /* lev on functionality */
        if (I == I_RANGE)
          current_state = STATE_CALIBRATE_LEV;
        else if (!I || !T || !CC || !WC || PS == PS_OFF)
          current_state = STATE_OFF;
        break;

      /*----------------------*/
      /* State: Calibrate lev */
      /*----------------------*/
      case STATE_CALIBRATE_LEV:
        /* calibrate lev functionality */
        timer2++;
        
        if ((I == I_FAIL && CC == 0 && WC == 0 && HVon == 1 && PS == PS_ON) || 
            (timer2 > someLimit && HVon == 1))
          current_state = STATE_EMERGENCY_BRAKE;
        else if ((I && T && CC && WC && PS && HVon == 0) || 
                 (T == T_FAIL && HVon == 1))
          current_state = STATE_OFF;
        else if (I == I_EQ)
          current_state = STATE_PROPULSION_ON;
        else if (I == 4) // Note: This value doesn't match enum - keeping it as in your provided code
          current_state = STATE_ACCELERATE;
        else if (I == 5) // Note: This value doesn't match enum - keeping it as in your provided code
          current_state = STATE_COAST;
        break;
      
      /*----------------------*/
      /* State: Propulsion on */
      /*----------------------*/
      case STATE_PROPULSION_ON:
        /* propulsion on functionality */
        if (I == I_OP || I == I_RANGE)
          current_state = STATE_CALIBRATE_LEV;
        else if ((T == T_OP || T == T_LEV) && (HE == HE_OP || HE == HE_LEV))
          current_state = STATE_PROPULSION_ON;
        else if (HVon == 1)
          current_state = STATE_ACCELERATE;
        else if (T == T_FAIL || PS == PS_OFF)
          current_state = STATE_OFF;
        else if (I == I_FAIL || CC == 0 || WC == 0)
          current_state = STATE_EMERGENCY_BRAKE;
        break;

      /*-------------------*/
      /* State: Accelerate */
      /*-------------------*/
      case STATE_ACCELERATE:
        /* accelerate functionality */
        if (IMU == IMU_TS)
          current_state = STATE_COAST;
        else if (IMU == IMU_BRAKE_DIST)
          current_state = STATE_NORMAL_BRAKE;
        else if (I == I_OP || I == I_RANGE)
          current_state = STATE_CALIBRATE_LEV;
        else if (T == T_FAIL || PS == PS_OFF)
          current_state = STATE_OFF;
        else if (I == I_FAIL || CC == 0 || WC == 0)
          current_state = STATE_EMERGENCY_BRAKE;
        break;

      /*--------------*/
      /* State: Coast */
      /*--------------*/
      case STATE_COAST:
        if (IMU == IMU_BRAKE_DIST)
          current_state = STATE_NORMAL_BRAKE;
        else if (I == I_OP || I == I_RANGE)
          current_state = STATE_CALIBRATE_LEV;
        else if (T == T_FAIL || PS == PS_OFF)
          current_state = STATE_OFF;
        else if (I == I_FAIL || CC == 0 || WC == 0)
          current_state = STATE_EMERGENCY_BRAKE;
        break;

      /*---------------------*/
      /* State: Normal brake */
      /*---------------------*/
      case STATE_NORMAL_BRAKE:
        timer3++;
        if (IMU == IMU_STOP)
          current_state = STATE_OFF;
        else if (timer3 > someLimit)
          current_state = STATE_EMERGENCY_BRAKE;
        else if (T == T_FAIL || PS == PS_OFF)
          current_state = STATE_OFF;
        break;
      
      /*------------------------*/
      /* State: Emergency brake */
      /*------------------------*/
      case STATE_EMERGENCY_BRAKE:
        if (IMU == IMU_STOP || T == T_FAIL || PS == PS_OFF)
          current_state = STATE_OFF;
        break;

      /*---------------*/
      /* State: Off */
      /*---------------*/
      case STATE_OFF:
        Off_Task();
        if (PS == PS_ON)
          current_state = STATE_INITIALIZE_ELECTRONICS;
        break;
    }
  }
  
  return 0;
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
