#include "Initialization_Helper.h"

/**
  * @brief Overall System Init
  * @retval None
  */
void Init_Config(void) {
    /* MCU Configuration--------------------------------------------------------*/

    /* USER CODE BEGIN Init */
    // Core system initialization
    HAL_Init();  // Initialize HAL layer and Systick
    /* USER CODE END Init */

    /* USER CODE BEGIN SysInit */
    // Configure system clocks (PLL, bus dividers, etc)
    SystemClock_Config();
    /* USER CODE END SysInit */

    // Initialize all peripherals
    MX_GPIO_Init();   // GPIO ports configuration
    MX_CAN1_Init();   // CAN communication setup
    MX_I2C1_Init();   // I2C interface configuration
    MX_TIM2_Init();   // Timer for PWM setup

    /* USER CODE BEGIN 2 */
    // Start PWM generation
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);

    // UNUSED: CAN bundle creation - could be used for data transfer
    CAN_Bundle cb = createCAN_Bundle(&hcan1);

    // Start CAN peripheral (Note: Called twice - possible redundancy)
    HAL_CAN_Start(&hcan1);

    // Enable CAN reception interrupt (Note: Activated twice - possible redundancy)
    HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING);

    // Commented out delay - might be needed for CAN stabilization
    //HAL_Delay(5000);
    HAL_CAN_Start(&hcan1);

    // Second CAN notification activation - possible redundancy
    HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING);

    // COMMENTED OUT CAN CONFIGURATION - Would set up CAN message parameters
    //TxHeader.DLC = 8; //data length
    //TxHeader.IDE = CAN_ID_STD;
    //TxHeader.RTR = CAN_RTR_DATA;
    //TxHeader.StdId = 0x001; //ID
    //TxData[0] = 0x03; //ms delay
    //TxData[1] = 0x22; //loop rep
    //TxData[2] = 0xF1;
    //TxData[3] = 0x00;
    //TxData[4] = 0x00;
    //TxData[5] = 0x00;
    //TxData[6] = 0x00;
    //TxData[7] = 0x00;
    //
    //HAL_GPIO_WritePin(CONTACTOR_2_GPIO_Port, CONTACTOR_2_Pin, 1);

    // POWER SEQUENCE START
    // SAFETY: Engage brakes first
    HAL_GPIO_WritePin(BRAKE_DIGITAL_GPIO_Port, BRAKE_DIGITAL_Pin, 0);

    // Commented out RTOS delay - alternative to HAL_Delay
    //vTaskDelay(5000);

    // Commented out CAN message transmission
    //HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox);

    // Begin power distribution sequence
    HAL_GPIO_WritePin(CONTACTOR_LEV_GPIO_Port, CONTACTOR_LEV_Pin, 0);
    HAL_GPIO_WritePin(CONTACTOR_3_GPIO_Port, CONTACTOR_3_Pin, 1);
    HAL_Delay(50);
    //vTaskDelay(50);  // Commented RTOS alternative
    HAL_GPIO_WritePin(CONTACTOR_1_GPIO_Port, CONTACTOR_1_Pin, 1);
    HAL_Delay(3000);
    //vTaskDelay(3000);  // Commented RTOS alternative
    HAL_GPIO_WritePin(CONTACTOR_2_GPIO_Port, CONTACTOR_2_Pin, 1);
    HAL_Delay(100);
    //vTaskDelay(100);  // Commented RTOS alternative
    HAL_GPIO_WritePin(CONTACTOR_1_GPIO_Port, CONTACTOR_1_Pin, 0);

    // VFD INITIALIZATION
    TIM2->CCR1 = 0; // Set PWM to 0
    HAL_GPIO_WritePin(VFD_FORWARD_GPIO_Port, VFD_FORWARD_Pin, 1);
    HAL_GPIO_WritePin(VFD_REVERSE_GPIO_Port, VFD_REVERSE_Pin, 0);

    // SAFETY: Release brakes after initialization
    HAL_GPIO_WritePin(BRAKE_DIGITAL_GPIO_Port, BRAKE_DIGITAL_Pin, 1);

    // Commented out CAN message - would send status/command
    //HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox);

    // Comment indicates heap check for RTOS scheduler
    // catching the case that not enough heap for scheduler

    /* USER CODE END 2 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CAN1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN1_Init(void)
{

  /* USER CODE BEGIN CAN1_Init 0 */

  /* USER CODE END CAN1_Init 0 */

  /* USER CODE BEGIN CAN1_Init 1 */

  /* USER CODE END CAN1_Init 1 */
  hcan1.Instance = CAN1;
  hcan1.Init.Prescaler = 18;
  hcan1.Init.Mode = CAN_MODE_NORMAL;
  hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan1.Init.TimeSeg1 = CAN_BS1_2TQ;
  hcan1.Init.TimeSeg2 = CAN_BS2_2TQ;
  hcan1.Init.TimeTriggeredMode = DISABLE;
  hcan1.Init.AutoBusOff = DISABLE;
  hcan1.Init.AutoWakeUp = DISABLE;
  hcan1.Init.AutoRetransmission = DISABLE;
  hcan1.Init.ReceiveFifoLocked = DISABLE;
  hcan1.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN1_Init 2 */

	CAN_FilterTypeDef canfilterconfig;

	canfilterconfig.FilterActivation = CAN_FILTER_ENABLE;


	canfilterconfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;

	canfilterconfig.FilterBank = 8; // which filter bank to use from the assigned ones
	canfilterconfig.FilterIdHigh = 0x002 << 5;
	canfilterconfig.FilterIdLow = 0;
	canfilterconfig.FilterMaskIdHigh = 0x002 << 5;
	canfilterconfig.FilterMaskIdLow = 0x0000;
	canfilterconfig.FilterMode = CAN_FILTERMODE_IDMASK;
	canfilterconfig.FilterScale = CAN_FILTERSCALE_32BIT;
	canfilterconfig.SlaveStartFilterBank = 0;  // does not matter
	HAL_CAN_ConfigFilter(&hcan1, &canfilterconfig);

//	canfilterconfig.FilterBank = 1; // which filter bank to use from the assigned ones
//	canfilterconfig.FilterIdHigh = 0x004 << 5;
//	canfilterconfig.FilterIdLow = 0;
//	canfilterconfig.FilterMaskIdHigh = 0x004 << 5;
//	canfilterconfig.FilterMaskIdLow = 0x0000;
//	canfilterconfig.FilterMode = CAN_FILTERMODE_IDMASK;
//	canfilterconfig.FilterScale = CAN_FILTERSCALE_32BIT;
//	canfilterconfig.SlaveStartFilterBank = 0;  // does not matter
//	HAL_CAN_ConfigFilter(&hcan1, &canfilterconfig);
//
//	canfilterconfig.FilterBank = 2; // which filter bank to use from the assigned ones
//	canfilterconfig.FilterIdHigh = 0x004 << 5;
//	canfilterconfig.FilterIdLow = 0;
//	canfilterconfig.FilterMaskIdHigh = 0x004 << 5;
//	canfilterconfig.FilterMaskIdLow = 0x0000;
//	canfilterconfig.FilterMode = CAN_FILTERMODE_IDMASK;
//	canfilterconfig.FilterScale = CAN_FILTERSCALE_32BIT;
//	canfilterconfig.SlaveStartFilterBank = 0;  // does not matter
//	HAL_CAN_ConfigFilter(&hcan1, &canfilterconfig);

  /* USER CODE END CAN1_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_OC_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_TIMING;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_OC_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, VFD_DIGITAL_Pin|CONTACTOR_2_Pin|CONTACTOR_3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, CONTACTOR_LEV_Pin|VFD_FORWARD_Pin|VFD_REVERSE_Pin|BRAKE_DIGITAL_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(CONTACTOR_1_GPIO_Port, CONTACTOR_1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : VFD_DIGITAL_Pin CONTACTOR_2_Pin CONTACTOR_3_Pin */
  GPIO_InitStruct.Pin = VFD_DIGITAL_Pin|CONTACTOR_2_Pin|CONTACTOR_3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : CONTACTOR_LEV_Pin VFD_FORWARD_Pin VFD_REVERSE_Pin BRAKE_DIGITAL_Pin */
  GPIO_InitStruct.Pin = CONTACTOR_LEV_Pin|VFD_FORWARD_Pin|VFD_REVERSE_Pin|BRAKE_DIGITAL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : USART_TX_Pin USART_RX_Pin */
  GPIO_InitStruct.Pin = USART_TX_Pin|USART_RX_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : CONTACTOR_1_Pin */
  GPIO_InitStruct.Pin = CONTACTOR_1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(CONTACTOR_1_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
  /* USER CODE END Error_Handler_Debug */
}