#include "stm32f4xx_hal.h"
// Define digital input pins
#define REF_PIN GPIO_PIN_0           // Run Enable
#define AUX_VOLTAGE_PIN GPIO_PIN_1   // High when system is on
#define ROTARY_ENABLE_PIN GPIO_PIN_2 // Same as REF
#define GND_PIN GPIO_PIN_3           // Always 0V
#define PROG1_PIN GPIO_PIN_4         // Programmable Digital Pin 1
#define PROG2_PIN GPIO_PIN_5         // Programmable Digital Pin 2
// Define PWM output pins
#define PWM_PLUS_PIN GPIO_PIN_6   // PWM Positive Terminal
#define PWM_MINUS_PIN GPIO_PIN_7  // PWM Negative Terminal
// Duty cycle control and polarity state
uint16_t duty_cycle = 50;  // 50% default
uint8_t polarity = 1;      // 1: Normal, 0: Inverted
TIM_HandleTypeDef htim3;  // Timer handle for PWM
// Function Prototypes
void SystemClock_Config(void);
void GPIO_Init(void);
void PWM_Init(void);
void Update_PWM(void);
int go(void) {
   HAL_Init();
   SystemClock_Config();  // Set up system clock
   GPIO_Init();           // Initialize GPIO pins
   PWM_Init();            // Initialize PWM on Timer 3
   HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1); // Start PWM+ (Channel 1)
   HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2); // Start PWM- (Channel 2)
   while (1) {
       // Check REF input: enable or disable PWM
       if (HAL_GPIO_ReadPin(GPIOA, REF_PIN) == GPIO_PIN_SET) {
           Update_PWM();  // REF high = system active
       } else {
           // REF low = system off → stop PWM output
           __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
           __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0);
       }
       // Toggle polarity if PROG1 is pressed
       if (HAL_GPIO_ReadPin(GPIOA, PROG1_PIN) == GPIO_PIN_SET) {
           polarity ^= 1;  // Invert polarity
           HAL_Delay(200); // Debounce delay
           Update_PWM();   // Apply change
       }
   }
}
// System Clock: Set to 84 MHz using HSI (16 MHz) and PLL
void SystemClock_Config(void) {
   RCC_OscInitTypeDef RCC_OscInitStruct = {0};
   RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
   // Configure main internal regulator output voltage
   __HAL_RCC_PWR_CLK_ENABLE();
   __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);
   // Initializes the RCC Oscillators using HSI and PLL
   RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
   RCC_OscInitStruct.HSIState = RCC_HSI_ON;
   RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
   RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
   RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
   RCC_OscInitStruct.PLL.PLLM = 16;
   RCC_OscInitStruct.PLL.PLLN = 336;
   RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;  // SYSCLK = 84 MHz
   RCC_OscInitStruct.PLL.PLLQ = 7;
   HAL_RCC_OscConfig(&RCC_OscInitStruct);
   // Initializes the CPU, AHB and APB buses clocks
   RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                               | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
   RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
   RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;   // 84 MHz
   RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;    // 42 MHz
   RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;    // 84 MHz
   HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2);
}
// GPIO setup
void GPIO_Init(void) {
   __HAL_RCC_GPIOA_CLK_ENABLE();
   GPIO_InitTypeDef GPIO_InitStruct = {0};
   // Digital inputs
   GPIO_InitStruct.Pin = REF_PIN | AUX_VOLTAGE_PIN | ROTARY_ENABLE_PIN | PROG1_PIN | PROG2_PIN;
   GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
   GPIO_InitStruct.Pull = GPIO_NOPULL;
   HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
   // PWM outputs
   GPIO_InitStruct.Pin = PWM_PLUS_PIN | PWM_MINUS_PIN;
   GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;  // Alternate function
   GPIO_InitStruct.Pull = GPIO_NOPULL;
   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
   GPIO_InitStruct.Alternate = GPIO_AF2_TIM3;  // TIM3 AF mapping
   HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}
// Timer 3 PWM setup for 100 kHz
void PWM_Init(void) {
   __HAL_RCC_TIM3_CLK_ENABLE();
   TIM_OC_InitTypeDef sConfigOC = {0};
   htim3.Instance = TIM3;
   htim3.Init.Prescaler = 0;  // With 84 MHz system clock, no prescaler
   htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
   htim3.Init.Period = 840 - 1;  // 100 kHz PWM: 84 MHz / 840 = 100 kHz
   htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
   HAL_TIM_PWM_Init(&htim3);
   // PWM Channel 1 = PWM_PLUS
   sConfigOC.OCMode = TIM_OCMODE_PWM1;
   sConfigOC.Pulse = duty_cycle * 8.4;  // 50% duty = 420 (out of 840)
   sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
   sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
   HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1);
   // PWM Channel 2 = PWM_MINUS
   sConfigOC.Pulse = 840 - (duty_cycle * 8.4);  // Inverse of above
   HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2);
}
// Updates the duty cycle and polarity
void Update_PWM(void) {
   if (polarity) {
       __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, duty_cycle * 8.4);
       __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 840 - (duty_cycle * 8.4));
   } else {
       __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 840 - (duty_cycle * 8.4));
       __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, duty_cycle * 8.4);
   }
}